import express from 'express';
import mongoose from 'mongoose';
import jwt from 'jwt-simple';
import QRCode from 'qrcode';
import cors from 'cors';
import bcrypt from 'bcryptjs';

const app = express();
const port = 5000;

// jwt secret key
const jwtSecretKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";

// Middleware
app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(express.json());

// MongoDB Connection
mongoose.connect(
  'mongodb+srv://anjaliguptacode:anjaligupta@cluster0.gpl804x.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
).then(() => console.log('Connected to MongoDB'))
 .catch((err) => console.error('MongoDB connection error:', err));

// Schemas
const userSchema = new mongoose.Schema({
  username: String,
  password: String,
});

const urlSchema = new mongoose.Schema({
  originalUrl: String,
  shortUrl: String,
  visitCount: { type: Number, default: 0 },
});

const User = mongoose.model('User', userSchema);
const ShortUrl = mongoose.model('ShortUrl', urlSchema);

// Auth Middleware
const authenticateJWT = (req, res, next) => {
  const token = req.header('Authorization');
  if (!token) return res.status(403).send('Access denied');

  try {
    const decoded = jwt.decode(token, jwtSecretKey);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(400).send('Invalid token');
  }
};



// Signup
app.post('/signup', async (req, res) => {
  const { username, password } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, password: hashedPassword });
    await user.save();
    res.status(201).send('User created');
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).send('Error creating user');
  }
});

// Login
// Example of login route in Node.js with Express
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  if (username === "test" && password === "password") {
    const token = generateToken(username); // Token generation logic
    return res.json({ token });
  } else {
    return res.status(401).json({ message: "Invalid credentials" });
  }
});

  

// Shorten URL + QR
app.post('/shorten', authenticateJWT, async (req, res) => {
  const { originalUrl } = req.body;

  try {
    const shortUrl = Math.random().toString(36).substring(2, 8);
    const newUrl = new ShortUrl({ originalUrl, shortUrl });
    await newUrl.save();

    const qrCode = await QRCode.toDataURL(`http://localhost:5000/${shortUrl}`);
    res.json({ shortUrl, qrCode });
  } catch (err) {
    console.error('Shorten error:', err);
    res.status(500).send('Error shortening URL');
  }
});

// Redirect
app.get('/:shortUrl', async (req, res) => {
  const { shortUrl } = req.params;

  try {
    const url = await ShortUrl.findOne({ shortUrl });
    if (!url) return res.status(404).send('URL not found');

    url.visitCount += 1;
    await url.save();
    res.redirect(url.originalUrl);
  } catch (err) {
    res.status(500).send('Error redirecting');
  }
});

// Dashboard
app.get('/dashboard', authenticateJWT, async (req, res) => {
  try {
    const stats = await ShortUrl.find();
    res.json(stats);
  } catch (err) {
    res.status(500).send('Error fetching dashboard data');
  }
});

// Server Start
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
