import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';
import Shortener from './components/Shortener';
import Dashboard from './components/Dashboard';
import Login from './components/auth/Login';
import Signup from './components/auth/Signup';

function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || "");

  return (
    <Router>
      <Routes>
        <Route 
          path="/login" 
          element={!token ? <Login onLogin={setToken} /> : <Navigate to="/" />} 
        />
        <Route 
          path="/signup" 
          element={!token ? <Signup /> : <Navigate to="/" />} 
        />
        <Route 
          path="/" 
          element={
            token ? (
              <div className='p-6 space-y-6'>
                <h1 className="text-3xl font-bold text-center">URL Shortener</h1>
                <Shortener token={token} />
                <Dashboard token={token} />
              </div>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;
