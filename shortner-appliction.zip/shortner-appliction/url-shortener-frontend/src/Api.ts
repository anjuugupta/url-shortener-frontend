const API_BASE = "http://localhost:5000";

export const signup = (data: { username: string; password: string }) =>
  fetch(`${API_BASE}/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  export const login = async (data: { username: string; password: string }) => {
    try {
      const res = await fetch(`${API_BASE}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
  
      console.log("Response status:", res.status);  // Log the status code
      if (!res.ok) {
        const errorText = await res.text(); // Get the error message from the server
        console.error("Server error message:", errorText); // Log the error
        throw new Error("Login failed");
      }
  
      const json = await res.json();
      console.log("Login success:", json); // Log the response from the server
      return json;
    } catch (error) {
      console.error("Login error:", error); // Log error on failure
      throw error;
    }
  };
  
  

export const shortenUrl = async (url: string, token: string) => {
  const res = await fetch(`${API_BASE}/shorten`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: token,
    },
    body: JSON.stringify({ originalUrl: url }),
  });
  return res.json();
};

export const getDashboardData = async (token: string) => {
  const res = await fetch(`${API_BASE}/dashboard`, {
    headers: {
      Authorization: token,
    },
  });
  return res.json();
};
