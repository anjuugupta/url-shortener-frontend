import { useEffect, useState } from "react";
import { getDashboardData } from "../Api";

export default function Dashboard({ token }: { token: string }) {
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    getDashboardData(token).then(setData);
  }, [token]);

  return (
    <div className="max-w-2xl mx-auto mt-6">
      <h2 className="text-xl font-bold mb-4">Your Links</h2>
      {data.map((item) => (
        <div key={item._id} className="border p-4 mb-2 rounded">
          <p><strong>Original:</strong> {item.originalUrl}</p>
          <p><strong>Short:</strong> {window.location.origin}/{item.shortUrl}</p>
          <p><strong>Visits:</strong> {item.visitCount}</p>
          <p><strong>Last Accessed:</strong> {item.lastAccessed ? new Date(item.lastAccessed).toLocaleString() : "Never"}</p>
        </div>
      ))}
    </div>
  );
}
