import { useState } from "react";
import { shortenUrl } from "../Api";

export default function Shortener({ token }: { token: string }) {
  const [url, setUrl] = useState("");
  const [shortUrl, setShortUrl] = useState("");
  const [qrCode, setQrCode] = useState("");

  const handleShorten = async () => {
    const data = await shortenUrl(url, token);
    setShortUrl(data.shortUrl);
    setQrCode(data.qrCode);
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      <input
        placeholder="Enter URL to shorten"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        className="input w-full"
      />
      <button onClick={handleShorten} className="bg-indigo-600 text-white p-2 rounded">Shorten</button>

      {shortUrl && (
        <div className="mt-4 p-4 bg-gray-100 rounded">
          <p>Short URL: <a href={`/${shortUrl}`} className="text-blue-600">{window.location.origin}/{shortUrl}</a></p>
          {qrCode && <img src={qrCode} alt="QR Code" className="mt-2" />}
        </div>
      )}
    </div>
  );
}
