import { useState } from "react";
import { login } from "../../Api";
import { useNavigate } from "react-router-dom";
import "./Login.css"; // Import the CSS file

export default function Login({ onLogin }: { onLogin: (token: string) => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false); // Track loading state
  const [errorMessage, setErrorMessage] = useState(""); // Store error messages
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Simple client-side validation
    if (!username || !password) {
      setErrorMessage("Please enter both username and password.");
      return;
    }

    setLoading(true); // Set loading state to true when submitting the form
    setErrorMessage(""); // Clear any previous error messages

    try {
      const data = await login({ username, password });
      if (data.token) {
        localStorage.setItem("token", data.token);
        onLogin(data.token);
        navigate("/dashboard");
      } else {
        setErrorMessage("Invalid credentials, please try again.");
      }
    } catch (error) {
      if (error instanceof Error) {
        setErrorMessage(error.message || "Login failed, please check your credentials.");
      } else {
        setErrorMessage("An unknown error occurred.");
      }
    } finally {
      setLoading(false); // Set loading state to false after request completion
    }
  };

  return (
    <form onSubmit={handleSubmit} className="login-form">
      <h2 className="text-center">Login</h2>
      {errorMessage && <div className="error-message">{errorMessage}</div>} {/* Error Message */}

      <input
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        className="input"
      />
      <input
        placeholder="Password"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="input"
      />

      <button type="submit" className="submit-button" disabled={loading}>
        {loading ? "Logging In..." : "Login"} {/* Dynamic Button Text */}
      </button>
    </form>
  );
}
